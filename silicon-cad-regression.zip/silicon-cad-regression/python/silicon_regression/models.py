"""Shared dataclasses (TestResult, Event, RunManifest, ...). Implemented in Phase 2."""
