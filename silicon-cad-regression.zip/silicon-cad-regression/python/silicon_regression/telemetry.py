"""Telemetry model and metric formulas. Implemented in Phase 10."""
