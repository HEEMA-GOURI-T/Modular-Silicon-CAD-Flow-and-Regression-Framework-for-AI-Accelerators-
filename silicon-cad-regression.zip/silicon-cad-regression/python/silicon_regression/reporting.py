"""Console/JSON/CSV/HTML reports and history. Implemented in Phase 12."""
