"""Command-line entry point. Real subcommands arrive in Phase 2."""
from __future__ import annotations

from typing import Optional, Sequence

from . import __version__


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Phase 1 placeholder: report version and exit non-zero (no commands yet)."""
    print(f"silicon-regression {__version__} (skeleton: CLI commands arrive in Phase 2)")
    return 2
