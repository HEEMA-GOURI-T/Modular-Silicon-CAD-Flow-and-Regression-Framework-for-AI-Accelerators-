"""Tcl/simulator driver wrapper (subprocess, timeouts). Implemented in Phase 7."""
