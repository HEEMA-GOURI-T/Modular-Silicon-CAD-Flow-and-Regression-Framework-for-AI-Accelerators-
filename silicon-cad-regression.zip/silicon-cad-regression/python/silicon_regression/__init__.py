"""Modular Silicon CAD Flow and Regression Framework for AI Accelerators."""

__version__ = "0.1.0"
