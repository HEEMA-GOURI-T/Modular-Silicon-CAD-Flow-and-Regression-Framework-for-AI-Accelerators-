# tcl/common.tcl - implemented in Phase 6
