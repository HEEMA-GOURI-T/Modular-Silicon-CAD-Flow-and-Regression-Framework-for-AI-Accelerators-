# tcl/simulate.tcl - implemented in Phase 6
