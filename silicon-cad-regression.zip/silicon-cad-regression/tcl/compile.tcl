# tcl/compile.tcl - implemented in Phase 6
