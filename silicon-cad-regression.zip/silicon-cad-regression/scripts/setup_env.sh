#!/usr/bin/env bash
set -euo pipefail
echo "scripts/setup_env.sh: not implemented yet (Phase 3)" >&2
exit 64
