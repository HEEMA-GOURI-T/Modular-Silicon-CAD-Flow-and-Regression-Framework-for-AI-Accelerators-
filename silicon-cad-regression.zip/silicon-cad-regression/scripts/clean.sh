#!/usr/bin/env bash
set -euo pipefail
echo "scripts/clean.sh: not implemented yet (Phase 6)" >&2
exit 64
