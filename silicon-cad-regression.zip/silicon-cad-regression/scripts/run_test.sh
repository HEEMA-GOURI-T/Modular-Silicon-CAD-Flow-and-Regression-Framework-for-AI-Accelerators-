#!/usr/bin/env bash
set -euo pipefail
echo "scripts/run_test.sh: not implemented yet (Phase 6)" >&2
exit 64
