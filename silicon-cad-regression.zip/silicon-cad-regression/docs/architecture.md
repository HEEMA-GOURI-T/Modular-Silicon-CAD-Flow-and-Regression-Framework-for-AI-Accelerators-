# Architecture

## Layered flow

```
CLI (python/silicon_regression/cli.py)
  -> Configuration Manager (config.py)          validated YAML/JSON -> dataclasses
  -> Regression Manager (regression.py)         discovery, scheduling, retries, timeouts
  -> Environment Manager (environment.py)       tool checks, versions, git SHA, config hash
  -> Tcl Simulation Driver (tcl/*.tcl)          compile / simulate / clean orchestration
  -> SystemVerilog RTL + Testbench (rtl/, tb/)  10 accelerator blocks + reusable TB
  -> Simulator (Verilator by default)           produces stdout/stderr + logs
  -> Logs / Telemetry (logs/<run_id>/<test>/)   [SIM] / [ERROR] lines
  -> C++ Parser (cpp/)                          high-throughput parsing and aggregation
  -> Python Analyzer (analyzer.py)              failure classification, regression checks
  -> Report Generator (reporting.py)            console / JSON / CSV / HTML
  -> History store (reports/history.*)          trend and regression detection
```

## Layer responsibilities and interfaces

| Layer | Responsibility | Input | Output |
|---|---|---|---|
| CLI | Argument parsing, exit codes | argv | calls library API |
| Config | Validate paths, test names, values | YAML/JSON | `RegressionConfig` |
| Regression Manager | Parallel execution, isolated run dirs | config | `list[TestResult]` |
| Environment Manager | Tool detection, `run_manifest.json` | system | `EnvReport` |
| Tcl Driver | Build/sim steps, exit status | env vars + args | simulator logs, exit code |
| RTL + TB | Functional models, checks, `[SIM]` logging | plusargs | log file |
| C++ Parser | Fast parse + aggregate (large logs) | log files | normalized JSON/CSV |
| Analyzer | Classify failures, compare runs | parsed data | verdicts |
| Reports | Human + machine output | verdicts | files |

## Language-placement rationale

- **Python**: orchestration, config, reports. I/O-bound, change-heavy, benefits from fast iteration.
- **C++**: log parsing/aggregation. CPU-bound over hundreds of MB; measured against the Python parser in Phase 15 (no pre-claimed speedup).
- **Tcl**: the interface most commercial simulators expose; keeps the flow portable to them.
- **SystemVerilog**: the design and verification content itself.
- **Bash**: thin entry points only; logic stays in Python.

## Design rules

1. Each test runs in its own directory (`runs/<run_id>/<test>/`), so parallel jobs never share files.
2. Subprocesses use argument arrays, never shell strings; config values are validated first.
3. Every run writes `run_manifest.json` (commit, config hash, seed, tool versions, command line).
4. Results are collected in a deterministic order (sorted by test name), not completion order.
5. Nothing is reported that was not measured; synthetic data is labeled synthetic.
