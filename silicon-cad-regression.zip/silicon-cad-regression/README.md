# Modular Silicon CAD Flow and Regression Framework for AI Accelerators

A Linux-first simulation and regression framework: Python orchestration, Tcl simulator
driver, SystemVerilog accelerator blocks and testbench, C++ log/telemetry processing,
reports, history, and CI.

**Status: Phase 1 of 18 (repository skeleton).** Nothing below is implemented yet
unless marked done. No benchmark or result numbers are claimed until measured.

| Phase | Item | Status |
|---|---|---|
| 1 | Architecture + skeleton | done |
| 2-18 | CLI, env, RTL, TB, Tcl, regression, parsers, analytics, reports, CI, docs | pending |

See [docs/architecture.md](docs/architecture.md).

## Quick start (Phase 1)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
```
