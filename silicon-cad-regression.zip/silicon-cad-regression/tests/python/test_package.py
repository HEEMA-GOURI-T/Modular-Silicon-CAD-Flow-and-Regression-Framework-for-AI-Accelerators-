import importlib

import pytest

MODULES = ["cli", "config", "environment", "simulator", "regression",
           "parser", "telemetry", "analyzer", "reporting", "models"]


def test_version_is_semver():
    import silicon_regression
    assert len(silicon_regression.__version__.split(".")) == 3


@pytest.mark.parametrize("name", MODULES)
def test_module_imports(name):
    importlib.import_module(f"silicon_regression.{name}")


def test_cli_placeholder_returns_nonzero(capsys):
    from silicon_regression.cli import main
    assert main([]) == 2
    assert "skeleton" in capsys.readouterr().out
