"""Fail if the repository skeleton drifts from the documented architecture."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

RTL = ["matrix_mul", "systolic_array", "vector_alu", "tensor_unit", "dma",
       "sram_controller", "noc_router", "instruction_decoder", "accumulator", "activation"]
TOP = ["README.md", "LICENSE", ".gitignore", "Makefile", "requirements.txt",
       "pyproject.toml", "CMakeLists.txt", ".github/workflows/regression.yml",
       "docs/architecture.md"]
DIRS = ["configs", "tb/common", "tb/interfaces", "tb/drivers", "tb/monitors",
        "tb/scoreboards", "tb/tests", "cpp/parser", "cpp/telemetry", "cpp/analyzer",
        "cpp/common", "cpp/tests", "tcl", "scripts", "logs", "reports",
        "tests/python", "tests/cpp", "tests/integration", "docs"]


def test_ten_rtl_block_dirs():
    for name in RTL:
        assert (ROOT / "rtl" / name).is_dir(), name
    assert len(RTL) == 10


def test_top_level_files():
    for f in TOP:
        assert (ROOT / f).is_file(), f


def test_directories():
    for d in DIRS:
        assert (ROOT / d).is_dir(), d


def test_shell_scripts_strict_and_executable():
    for sh in (ROOT / "scripts").glob("*.sh"):
        assert "set -euo pipefail" in sh.read_text(), sh.name
        assert sh.stat().st_mode & 0o111, f"{sh.name} not executable"
